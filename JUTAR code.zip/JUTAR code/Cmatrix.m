function [b]=Cmatrix(M)
    a=[1:M];
    [m,n]=find(mod(a,3)~=0);
    b=zeros(1,M);
    l_1=length(n);
    for i=1:l_1
        b(i,n(i))=1;
    end
end
    



% a(1,1)=1;
% a(2,2)=1;
% a(3,4)=1
% a(4,5)=1