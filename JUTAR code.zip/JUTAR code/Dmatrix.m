function [b]=Dmatrix(M)
%     M=6;
    a=[1:M];
    [m,n]=find(mod(a,3)==0);
    b=zeros(1,M);
    l_1=length(n);
    for i=1:l_1
        b(i,n(i))=1;
    end
end

  