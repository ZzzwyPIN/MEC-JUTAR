
function [b]=Bmatrix(M)
%     M = 15;
    b=[];
    for i=1:3:M
        a=zeros(1,M);
        if mod(i,3)~=0
            a(i)=1;
            a(i+1)=1;
            a(i + 2) = 0; 
        end
        b = [b;a];
    end
    % b
end
