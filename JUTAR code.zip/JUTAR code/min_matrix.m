
function [a]=min_matrix(M,s)
a=ones(M,1);
for i=1:M
    if mod(i,3)~=0
        a(i,1)=-1;
    else
        a(i,1)=-s;
    end
end
end
